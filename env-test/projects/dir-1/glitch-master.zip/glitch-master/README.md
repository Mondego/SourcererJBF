![GLITCH](./Resources/Misc/glitch.png )

<br>

GLITCH is a puzzle platformer designed to challenge your memory, patience, and platforming skills!

## Download
|  [<img src="https://i.imgur.com/POJjnum.png" alt="Windows" width="24px" height="24px" />]()</br> Windows  |          [<img src="https://i.imgur.com/V0YkvU5.png" alt="Mac" width="24px" height="24px" />]()</br> Mac          |         [<img src="https://i.imgur.com/khCS5Ll.png" alt="Linux" width="24px" height="24px" />]()</br> Linux         |
|:---------:|:---------------------:|:---------------------:|
| [Download](https://github.com/0kzh/glitch/releases/tag/1.0) | [Download](https://github.com/0kzh/glitch/releases/tag/1.0) | [Download](https://github.com/0kzh/glitch/releases/tag/1.0) |
## Screenshots
![Screenshot 1](./.screenshots/1.png)
![Screenshot 2](./.screenshots/2.png)
![Screenshot 3](./.screenshots/3.png)