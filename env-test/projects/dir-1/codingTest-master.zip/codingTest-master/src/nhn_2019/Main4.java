package nhn_2019;
import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
class Main4 {
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		int num[] = new int[101];
	}
}