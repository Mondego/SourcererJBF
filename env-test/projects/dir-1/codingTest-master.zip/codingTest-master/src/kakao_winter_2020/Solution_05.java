package kakao_winter_2020;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Solution_05 {
	public static int[] solution(int[][] v) {
        int[] answer = {};

        System.out.println("Hello Java");

        return answer;
    }
	
	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("res/kakao_intern_2020/sol_05.txt"));
		int[][] s = {{},{}};
		solution(s);
	}
}
