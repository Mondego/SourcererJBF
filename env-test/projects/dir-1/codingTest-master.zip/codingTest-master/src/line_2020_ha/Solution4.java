package line_2020_ha;

public class Solution4 {
	
    static public int solution(int[][] boxes) {
        int answer = -1;
        return answer;
    }
	
	
	public static void main(String[] args) {
		int boxes[][] = {{1},{1}};
		System.out.println("[정답]"+solution(boxes));
	}
	
	
	
}
