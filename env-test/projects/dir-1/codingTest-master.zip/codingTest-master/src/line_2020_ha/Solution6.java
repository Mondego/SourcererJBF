package line_2020_ha;

import java.util.HashMap;
import java.util.Map;

public class Solution6 {
	
    static public int solution(int[][] boxes) {
        int answer = -1;
        return answer;
    }
	
	
	public static void main(String[] args) {
		int boxes[][] = {{1,2},{2,1},{3,3},{4,5},{5,6},{7,8}};
		System.out.println("[정답]"+solution(boxes));
	}
	
	
	
}
