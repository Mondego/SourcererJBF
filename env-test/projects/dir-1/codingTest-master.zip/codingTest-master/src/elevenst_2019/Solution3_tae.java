package elevenst_2019;
public class Solution3_tae {
	public static int solution(int n, String[] plates, int[] odo, int k, int[] drives) {
		int ans = 0;
		
		return ans;
	}

	public static void main(String[] args) {
		int n = 6;
		String plates[] = {"AZ3618","XP9657","SP6823","UH7515","TV6621","WZ8264"};
		int[] odo= {20,16,18,20,24,19};
		int k=8;
		int[] drives = {3,7,5,8,6,5,10,2};
		
		
		System.out.println(solution(n,plates,odo,k,drives));
	}
}
