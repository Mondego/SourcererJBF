package kakao_2021_blind;

public class Solution_07 {
	public static String solution(String new_id) {
		String answer = "";
		return answer;
	}
	
	public static void main(String[] args) {
		String new_id = "\"...!@BaT#*..y.abcdefghijklm\"";
		System.out.println("[정답] "+solution(new_id));
	}

	
}
