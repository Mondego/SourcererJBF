package netmarble_2019;
public class Solution7 {
	private static int solution(int h, int w, int n, String[] map) {
		int ans = 0;
		ans = 0;
		return ans;
	}

	public static void main(String[] args) {
		int h = 7;
		int w = 9;
		int n = 4;
		String[] map = {"111100000",
						"000010011",
						"111100011",
						"111110011",
						"111100011",
						"111100010",
						"111100000",};
		
		int h2 = 5;
		int w2 = 5;
		int n2 = 5;
		String[] map2 = {"11111",
						"11111",
						"11111",
						"11111",
						"11111"};
		System.out.println(solution(h2,w2,n2,map2));
	}
}
