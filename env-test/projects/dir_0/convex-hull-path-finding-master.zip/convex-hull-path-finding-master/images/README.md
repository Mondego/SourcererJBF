Directory of Images for README
